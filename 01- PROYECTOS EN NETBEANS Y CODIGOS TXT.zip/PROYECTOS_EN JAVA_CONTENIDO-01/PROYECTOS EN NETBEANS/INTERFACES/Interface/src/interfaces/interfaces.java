package interfaces;

public class interfaces {

public static void main(String[] args) {
Empleado aux = new Empleado();
aux.asignarDepto();
aux.asignarOperadora();
}
}




