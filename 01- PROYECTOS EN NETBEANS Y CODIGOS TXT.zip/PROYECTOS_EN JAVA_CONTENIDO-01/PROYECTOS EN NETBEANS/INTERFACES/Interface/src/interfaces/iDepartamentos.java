/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

public interface iDepartamentos {
    
//se crea un vector de cadena y se inicializa con sus respectivos valores
public static final String dptos[] = {"Recursos Humanos","Informática",
"Financiero","Contabilidad","Ventas"};
//se inicializa un vector de enteros con sus respectivos valores
public static final int exts[] = {123,345,324,125,423};
//se crear un método vacío (sin implementar)
void asignarDepto();
}