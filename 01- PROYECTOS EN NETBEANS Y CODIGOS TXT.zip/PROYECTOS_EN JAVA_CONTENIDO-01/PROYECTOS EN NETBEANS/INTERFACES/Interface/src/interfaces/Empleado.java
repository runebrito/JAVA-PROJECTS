/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.util.Scanner;
//implementación de la clase Empleado con las interfaces antes creadas.
public class Empleado implements iDepartamentos,iOperadoraPension{
int i;
//se crea una variable tipo Scanner para realizar lecturas desde teclado
Scanner Lector = new Scanner(System.in);
@Override //para implementar el método asignarDepto
public void asignarDepto() {
int dpto,ext;
String nombre;
System.out.print("Escriba Nombre del empleado : ");
nombre = Lector.next(); //se lee de teclado el contenido para nombre
for(i=0;i<dptos.length;i++) //se recorre el vector dptos.
System.out.println(i+1+" "+ dptos[i]); //se muestran valores del vector
System.out.print("Seleccione Departamento : ");
dpto = Lector.nextInt(); //lee por teclado una variable de tipo entera
System.out.println("Departamento seleccionado : "+dptos[dpto-1]);
for(i=0;i<exts.length;i++) //se recorre el vector de extensiones
System.out.println(i+1+" "+ exts[i]); //despliega cada valor del vector
System.out.print("Seleccione la Extensión : ");
ext = Lector.nextInt();
System.out.println("Extensión : "+exts[ext-1]);
}
@Override
public void asignarOperadora() {
int opera,tasa;
for(i=0;i<entidades.length-1;i++)
System.out.println(i+1+" "+ entidades[i]);
System.out.print("Seleccione la Operadora : ");
opera = Lector.nextInt();
System.out.println("Departamento seleccionado : "+entidades[opera-1]);
for(i=0;i<tasaRinde.length-1;i++)
System.out.println(i+1+" "+ tasaRinde[i]);
System.out.print("Seleccione la tasa de rendimiento: ");
tasa = Lector.nextInt();
System.out.println("Extensión : "+tasaRinde[tasa-1]);
}}

