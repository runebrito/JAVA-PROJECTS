/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

public interface iOperadoraPension {
    
//se crea un vector de cadena con sus respectivos valores
public static final String entidades[] = {"Banco de Pensiones",
"Pensiones Costa Rica", "Banco Municipal",
"Sistema de Pensiones","Pensiones Acme"};
//se crea un vector de tipo double con sus respectivos valores
public static final double tasaRinde[] = {0.11,0.12,0.13,0.14,0.15};
void asignarOperadora();
}
