
package javaapplication1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GestionBoton implements ActionListener {

    private int contador=0;
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println("El Botón ha sido pulsado " + contador + "veces" );
        contador++;
    }
    
}
