

public class Matriz {


public static void main(String[] args) {

int matriz[][] = new int[3][4];		
matriz[0][1] = 17; matriz[1][1] = 64; matriz[2][1] = 83;
matriz[0][2] = 65; matriz[1][2] = 33; matriz[2][2] = 28;
matriz[0][3] = 28; matriz[1][3] = 17; matriz[2][3] = 99;
matriz[0][3] = 28; matriz[1][3] = 17; matriz[2][3] = 99;
System.out.println("Contenido " + matriz[0][2]);
System.out.println("Contenido " + matriz[0][3]);
}  
}

    
    

