import java.util.Scanner;

public class Matriz02 {    
                     
public static void main(String[] args) {

//Declaramos el numero de filas y columnas de la matriz
        final int FILAS = 3, COLUMNAS = 2;
        Scanner sc = new Scanner(System.in);
        int i, j, mayor, menor;
        int filaMayor, filaMenor, colMayor, colMenor;

        int[][] A = new int[FILAS][COLUMNAS]; //Se crea una matriz de 5 filas y 4 columnas

//Se introducen por teclado los valores de la matriz
        System.out.println("Lectura de elementos de la matriz: ");
        for (i = 0; i < FILAS; i++) {
            for (j = 0; j < COLUMNAS; j++) {
                System.out.print("A[" + i + "][" + j + "]= ");
                A[i][j] = sc.nextInt();
            }
        }
        
//Mostrar por pantalla los valores que contiene la matriz
        System.out.println("valores introducidos:");
        for (i = 0; i < A.length; i++) { 
            for (j = 0; j < A[i].length; j++) {
                System.out.print(A[i][j] + " ");
            }
            System.out.println();
        }
        
//Calculamos el mayor valor de la matriz y el menor.
//Obtenemos las posiciones que ocupan el mayor y el menor dentro de la matriz 
        mayor = menor = A[0][0]; //se toma el primer elemento de la matriz como mayor y menor
        filaMayor = filaMenor = colMayor = colMenor = 0;

//Mediante dos bucles for anidados recorremos la matriz
//Buscamos el mayor, el menor y sus posiciones
        for (i = 0; i < A.length; i++) {  //para cada fila de la matriz
            for (j = 0; j < A[i].length; j++) { //para cada columna de la matriz
                if (A[i][j] > mayor) {
                    mayor = A[i][j];
                    filaMayor = i;
                    colMayor = j;
                } else if (A[i][j] < menor) {
                    menor = A[i][j];
                    filaMenor = i;
                    colMenor = j;
                }
            }           
        }

//Se muestra en pantalla el mayor elemento de la matriz,el menor y las posiciones que ocupan           
        System.out.print("Elemento mayor: " + mayor);
        System.out.println(" --> Ubicado en la Fila: "+ filaMayor + " y columna: " + colMayor);
        System.out.print("Elemento menor: " + menor);
        System.out.println(" --> Ubicado en la Fila: "+ filaMenor + " y columna: " + colMenor);
    }
}

