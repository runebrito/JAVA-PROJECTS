public class DatosTipoEntero {



public static void main(String[] args) {

byte dato1 = 1;
short dato2 = 10;
int dato3 = 1000;
long dato4 = 100000000;

System.out.println("Dato tipo byte " + dato1);
System.out.println("Dato posicion 2 " + dato2);
System.out.println("Dato posicion 3 " + dato3);
System.out.println("Dato posicion 3 " + dato4);

}  
}






