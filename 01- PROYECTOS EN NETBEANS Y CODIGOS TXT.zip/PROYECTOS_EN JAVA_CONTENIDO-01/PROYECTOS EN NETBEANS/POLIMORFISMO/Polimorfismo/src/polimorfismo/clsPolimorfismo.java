package polimorfismo;

public class clsPolimorfismo {
int sumar(int a, int b) {
return a+b; //retorna un valor de tipo entero
}
double sumar(double a, double b) {
return a+b; } //retorna un valor de tipo double
String sumar(String a, String b) {
return a+b; } //retorna un valor de tipo cadena
}


