package polimorfismo;

public class Polimorfismo {

public static void main(String[] args) {
clsPolimorfismo aux = new clsPolimorfismo();
System.out.println("Suma de Enteros: "+ aux.sumar(2, 3));
System.out.println("Suma de Cadenas: "+ aux.sumar("Enrique", " Gomez"));
System.out.println("Suma de Doubles: "+ aux.sumar(2.5, 3.3)); }
}
    
