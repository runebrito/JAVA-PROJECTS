/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplotercero;

public class bicicleta extends vehiculo {
@Override
public void registrarVehiculo() {
System.out.print("Ingrese el color de la bicicleta: ");
color = Lector.next();
System.out.print("Ingrese el precio de la bicicleta: ");
precio = Lector.nextInt(); }
}



