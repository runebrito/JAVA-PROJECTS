/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplotercero;

import java.util.Scanner;

public abstract class vehiculo {
protected int modelo;
protected String color;
protected String marca;
protected double precio;
Scanner Lector = new Scanner(System.in); //para procesar lecturas de
//teclado a usar en clases
//derivadas
public vehiculo (int modelo, String color, String marca, double precio )
{
this.modelo = modelo;
this.color = color;
this.marca = marca;
this.precio = precio;
}
 
public vehiculo()
{}
public abstract void registrarVehiculo();

}