/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplotercero;
public class automovil extends vehiculo {
@Override
public void registrarVehiculo() {
String estilo; //coupe, sedan, compacto...
System.out.print("Ingrese el año del automóvil: ");
modelo = Lector.nextInt();
System.out.print("Ingrese el color del automóvil: ");
color = Lector.next();
System.out.print("Ingrese el precio del automóvil: ");
precio = Lector.nextInt(); }
}
