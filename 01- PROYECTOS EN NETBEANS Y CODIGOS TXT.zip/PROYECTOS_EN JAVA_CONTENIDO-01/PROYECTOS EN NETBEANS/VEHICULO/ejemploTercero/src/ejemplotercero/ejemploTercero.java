
package ejemplotercero;

public class ejemploTercero {
  
public static void main(String[] args) {
bicicleta Bicicleta = new bicicleta();
Bicicleta.registrarVehiculo();
automovil Automovil = new automovil();
Automovil.registrarVehiculo();
}
}

